<?php
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
ini_set('display_errors', 0);
error_reporting(0);
/* =========================
   Helpers
========================= */
function respond(bool $success, string $message, int $code = 200): void {
    http_response_code($code);
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}
function clean($v): string {
    return trim((string)$v);
}
function h($v): string {
    return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}


define('WEBHOOK_URL', 'https://affiliate.arabinfotechllc.com/index.php/webhooks/crm');
define('WEBHOOK_SECRET', '9zPouKYgGFQyeMvEJsiqtTie');
/* =========================
   Honeypot
========================= */
if (!empty($_POST['hp_name'])) {
    respond(true, 'Thanks!');
}

/* =========================
   Read form fields
========================= */
$business     = clean($_POST['business_name'] ?? '');
$name         = clean($_POST['contact_person'] ?? '');
$phone        = clean($_POST['phone'] ?? '');
$email        = clean($_POST['email'] ?? '');
$products     = clean($_POST['products_count'] ?? '');
$payment      = clean($_POST['payment_gateway'] ?? '');
$budget       = clean($_POST['budget_range'] ?? '');
$timeline     = clean($_POST['timeline'] ?? '');
$notes        = clean($_POST['notes'] ?? '');
$ad_source    = clean($_POST['ad_source'] ?? '');
$sourcetag    = clean($_POST['sourcetag'] ?? '');
$utm_campaign = clean($_POST['utm_campaign'] ?? '');


if (!$business || !$name || !$phone || !$payment || !$email || !$products || !$timeline) {
    respond(false, 'Please fill all required fields.', 400);
}
if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(false, 'Invalid email address.', 400);
}


/* =========================
   reCAPTCHA v3
========================= */
$token = $_POST['recaptcha_token'] ?? '';
$secretKey = '6Ld0nUAsAAAAACSKi9MO6nAy2NovHzlg8l04TSyP'; // 🔒 your SECRET key
if (!$token) {
    respond(false, 'Captcha validation failed.', 400);
}
$verify = @file_get_contents(
    'https://www.google.com/recaptcha/api/siteverify?secret=' .
    urlencode($secretKey) . '&response=' . urlencode($token)
);
if (!$verify) {
    respond(false, 'Captcha service unavailable.', 400);
}
$captcha = json_decode($verify, true);
if (
    empty($captcha['success']) ||
    ($captcha['score'] ?? 0) < 0.5 ||
    ($captcha['action'] ?? '') !== 'submit'
) {
    respond(false, 'Captcha verification failed.', 400);
}

/* =========================
   Rate limit (IP based)
========================= */
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$file = sys_get_temp_dir() . '/inq_' . md5($ip);
if (file_exists($file) && time() - filemtime($file) < 10) {
    respond(false, 'Too many requests. Please try again.', 429);
}
touch($file);


/* =========================================================
   SEND TO CRM WEBHOOK
========================================================= */

$remarks = "";
if (!empty($products)) {
  $remarks .= "No. of Products (Approx.): {$products}\n";
}
if (!empty($payment)) {
  $remarks .= "Need Payment Gateway?: {$payment}\n";
}
if (!empty($budget)) {
  $remarks .= "Budget Range (Optional): {$budget}\n";
}
if (!empty($timeline)) {
  $remarks .= "Target Timeline: {$timeline}\n";
}
if (!empty($notes)) {
  $remarks .= "Notes: {$notes}";
}



$payload = [
    'name'       => $name,
    'contact_type'    => 4,
    'email'      => $email,
    'mobile'     => $phone,
    'company'    => $business,
    'remarks'    => $remarks,
    'status'     => 1,
    'completed_percentage' => 0,
    'contact_source' => 22,
    'contact_priority' => 2,
    'created_at' => date('Y-m-d H:i:s'),
    'ad_source'  => $ad_source,
    'sourcetag'  => $sourcetag,
    'utm_campaign' => $utm_campaign
];

$payloadJson = json_encode($payload);
$signature = hash_hmac('sha256', $payloadJson, WEBHOOK_SECRET);

$ch = curl_init(WEBHOOK_URL);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => $payloadJson,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'X-Webhook-Signature: ' . $signature,
    'Content-Length: ' . strlen($payloadJson),
    'Origin: https://arabinfotec.com'
    ],
     CURLOPT_REFERER => 'https://arabinfotec.com/e-commerce/',
    CURLOPT_TIMEOUT => 5,
    CURLOPT_SSL_VERIFYPEER => true
]);
curl_exec($ch);
curl_close($ch);


/* =========================
   Webhooks Configuration - Disabled
========================= */

/*
$webhook_url = 'https://affiliate.arabinfotechllc.com/wesite_webhook.php';
$webhook_secret = '9zPouKYgGFQyeMvEJsiqtTie'; // Use a strong random string
$remarks = "";
if (!empty($products)) {
  $remarks .= "No. of Products (Approx.): {$products}\n";
}
if (!empty($payment)) {
  $remarks .= "Need Payment Gateway?: {$payment}\n";
}
if (!empty($budget)) {
  $remarks .= "Budget Range (Optional): {$budget}\n";
}
if (!empty($timeline)) {
  $remarks .= "Target Timeline: {$timeline}\n";
}
if (!empty($notes)) {
  $remarks .= "Notes: {$notes}";
}

$webhook_data = [
    'name'            => $name,
    'contact_type'    => 4,
  	'email'           => $email,
  	'mobile'          => $phone,
    'company'         => $business,
    'remarks'         => $remarks,
  	'status'		  => 1,
  	'completed_percentage' => 0,
    'contact_source'  => 22,
    'contact_priority'=> 2,
    'contact_states' => 1,
    'created_at'      => date('Y-m-d H:i:s'),
    'ad_source' => $ad_source,
    'sourcetag' => $sourcetag,
    'utm_campaign' => $utm_campaign
];

$webhook_json = json_encode($webhook_data);
// Define your source URL
$source_url = 'https://arabinfotec.com';
$exact_page = 'https://arabinfotec.com/e-commerce/';
// Generate signature for CRM verification
$signature = hash_hmac('sha256', $webhook_json, $webhook_secret);
// Send via cURL (More reliable than file_get_contents)
$ch = curl_init($webhook_url);
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS     => $webhook_json,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'X-Webhook-Signature: ' . $signature,
        'Content-Length: ' . strlen($webhook_json),
      	// This populates $_SERVER['HTTP_ORIGIN'] on the receiver
        'Origin: ' . $source_url
    ],
  	// This populates $_SERVER['HTTP_REFERER'] on the receiver
    CURLOPT_REFERER        => $exact_page,
    CURLOPT_TIMEOUT        => 5,    // CRM must respond within 5s
    CURLOPT_CONNECTTIMEOUT => 3,    // Connection timeout
    CURLOPT_SSL_VERIFYPEER => true, // Ensure secure connection
]);
$webhook_response = curl_exec($ch);
$webhook_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
if (curl_errno($ch)) {
    error_log('Webhook cURL Error: ' . curl_error($ch));
}
curl_close($ch);

*/

/* =========================
   PHPMailer
========================= */
require __DIR__ . '/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'server.virtualsystec.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'mailer@arabinfotec.com';
    $mail->Password   = '2uumwpFKXA8Y'; // 🔴 move to ENV later
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->CharSet = 'UTF-8';
    $mail->Encoding = 'base64';
    $mail->isHTML(true);
    $mail->setFrom('mailer@arabinfotec.com', 'Arabinfotec – E-Commerce (UAE)');
    $mail->MessageID = sprintf('<%s@arabinfotec.com>', bin2hex(random_bytes(16)));
    $mail->XMailer   = 'Arabinfotec Mailer';
    $mail->addCustomHeader('Precedence', 'bulk');
    $mail->addAddress('hello@arabinfotec.com');
	  $mail->addCC('praveen@vstbiz.com', 'Praveen VsT');
    $mail->addCC('info@arabinfotechllc.com', 'Arabinfotechllc');
     $mail->addCC('sreechand@arabinfotechllc.com', 'Sreechand KS');
    $mail->addCC('sreechand@vstbiz.com', 'SREECHAND KS');
    $mail->addCC('sangeeta@vstbiz.com', 'Sangeeta Sreeni');
    $mail->addCC('hello@arabinfotec.com', 'Hello - Arabinfotec – E-Commerce (UAE)');
    //
	//
	//$mail->addCC('sangeeta@arabinfotechllc.com', 'Sangeeta Sreenivasan');
   if ($email) {
        $mail->addReplyTo($email, $name);
        } else {
        $mail->addReplyTo('hello@arabinfotec.com', 'Arabinfotec');
        }
    $mail->Subject = "New consultation request from {$business}";
    $year = date('Y');
  $mail->Body = "
<div style='font-family:Arial,Helvetica,sans-serif;color:#1f2937;font-size:14px;line-height:1.6'>
  <h2 style='margin:0 0 12px;color:#0f172a'>New Consultation Request</h2>
  <p>You have received a new enquiry from the website.</p>
  <table cellpadding='6' cellspacing='0' style='border-collapse:collapse;font-size:14px'>
    <tr><td><strong>Business Name</strong></td><td>".h($business)."</td></tr>
    <tr><td><strong>Contact Person</strong></td><td>".h($name)."</td></tr>
    <tr><td><strong>Phone / WhatsApp</strong></td><td>".h($phone)."</td></tr>
    <tr><td><strong>Email</strong></td><td>".h($email ?: '—')."</td></tr>
    <tr><td><strong>No. of Products</strong></td><td>".h($products ?: '—')."</td></tr>
    <tr><td><strong>Payment Gateway</strong></td><td>".h($payment)."</td></tr>
    <tr><td><strong>Budget Range</strong></td><td>".h($budget ?: '—')."</td></tr>
    <tr><td><strong>Target Timeline</strong></td><td>".h($timeline ?: '—')."</td></tr>
    <tr><td><strong>Source Type</strong></td><td>".h($ad_source ?: '—')."</td></tr>
  </table>
  <p style='margin-top:14px'><strong>Notes</strong></p>
  <div style='background:#f8fafc;border-left:4px solid #0e7cc7;padding:12px'>
    ".nl2br(h($notes ?: '—'))."
  </div>
  <hr style='margin:18px 0;border:none;border-top:1px solid #e5e7eb'>
  <p style='font-size:12px;color:#6b7280'>
    This message was sent from <strong>arabinfotec.com</strong><br>
    E-Commerce Development (UAE)<br>
    <a href='https://arabinfotec.com/e-commerce' style='color:#0e7cc7;text-decoration:none'>
      https://arabinfotec.com/e-commerce
    </a>
  </p>
</div>
";
$mail->AltBody =
"New Consultation Request
Business Name: $business
Contact Person: $name
Phone / WhatsApp: $phone
Email: " . ($email ?: '-') . "
No. of Products: " . ($products ?: '-') . "
Payment Gateway: $payment
Budget Range: " . ($budget ?: '-') . "
Target Timeline: " . ($timeline ?: '-') . "
Notes:
" . ($notes ?: '-');
    $mail->send();
    respond(true, 'Thanks — we will contact you shortly.');
} catch (Exception $e) {
    error_log('Mail error: '.$e->getMessage());
    respond(false, 'Internal server error. Please try again later.', 500);
}
