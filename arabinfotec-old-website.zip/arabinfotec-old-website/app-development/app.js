// Arabinfotec Landing v13 – lightweight interactions
const industries = {
  "Valet Parking Solution": {
    desc: "Smart valet management apps for seamless vehicle handling, staff coordination, and customer experience.",
    bullets: ["Digital ticketing","Live vehicle tracking","Staff assignment","Customer notifications","Performance dashboards"]
  },
  "Competency Analytics System": {
    desc: "Data-driven platforms to measure workforce skills, performance, and training needs",
    bullets: ["Competency tracking","Employee assessments","Skill gap analytics","Reporting dashboards","Role-based access"]
  },
  "Manpower Supply Software": {
    desc: "Mobile-first workforce management apps for staffing, attendance, and approvals.",
    bullets: ["Staff scheduling","Attendance monitoring","Client approvals","Payroll-ready reports","Workforce dashboards"]
  },
  "ShortlistPRO": {
    desc: "Recruitment and candidate shortlisting platforms built for speed and accuracy.",
    bullets: ["Candidate database","Smart filtering","Interview workflows","Status tracking","Hiring dashboards"]
  },
  "Software Solutions": {
    desc: "Custom software platforms tailored to automate business operations and improve efficiency.",
    bullets: ["Workflow automation","Data management","Reporting systems","Scalable architecture","Secure deployment"]
  },
   "Mobile Application Development": {
    desc: "High-performance Android & iOS apps designed for business growth and user engagement.",
    bullets: ["Native & Flutter apps","Secure mobile workflows","Real-time dashboards","Cloud integration","App store deployment"]
  },
  "Domain & Servers": {
    desc: "Reliable infrastructure services to host, manage, and scale business applications securely.",
    bullets: ["Domain setup","Cloud hosting","Server management","Security monitoring","Backup solutions"]
  },
  "Custom Software Development": {
    desc: "End-to-end development of scalable software products built for your unique business needs.",
    bullets: ["Requirement planning","UI/UX design","Backend development","API integrations","Ongoing support"]
  }
};

function toggleMenu(forceClose=false){
  const m = document.getElementById('mobileNav');
  const btn = document.querySelector('.nav__toggle');
  const expanded = btn.getAttribute('aria-expanded') === 'true';
  const next = forceClose ? false : !expanded;
  btn.setAttribute('aria-expanded', String(next));
  if(next){
    m.hidden = false;
  } else {
    m.hidden = true;
  }
}

function openDiagnosis(){
  const modal = document.getElementById('modal');
  modal.classList.add('is-open');
  modal.setAttribute('aria-hidden','false');
}
function closeModal(){
  const modal = document.getElementById('modal');
  modal.classList.remove('is-open');
  modal.setAttribute('aria-hidden','true');
}
function makeRecommendation(){
  const a = document.getElementById('q1').value;
  const b = document.getElementById('q2').value;
  const c = document.getElementById('q3').value;

  const list = [];
  if(a.includes('spreadsheets')) list.push('Single Source Database','Dashboards');
  if(a.includes('Approvals')) list.push('Workflow + Approvals','Reminders');
  if(a.includes('visibility')) list.push('KPI Dashboard','Reports');
  if(a.includes('Document')) list.push('Document Vault','Expiry Alerts');

  if(b.includes('Field')) list.push('Mobile Updates','Geo Logs');
  if(c.includes('Workflow')) list.push('Roles & Approvals');
  if(c.includes('Dashboards')) list.push('Executive View');
  if(c.includes('Mobile')) list.push('Field App');
  if(c.includes('Document')) list.push('Compliance Pack');

  const uniq = [...new Set(list)].slice(0,8);
  const el = document.getElementById('recommendList');
  el.innerHTML = uniq.map(x=>`<span>${x}</span>`).join('');
  const box = document.getElementById('recommend');
  box.style.display = 'block';
}

function copyLink(){
  try{
    navigator.clipboard.writeText(location.href);
    alert('Link copied.');
  }catch(e){
    prompt('Copy this link:', location.href);
  }
}

// Industry chips
document.addEventListener('click', (e)=>{
  const btn = e.target.closest('.chipbtn');
  if(!btn) return;
  document.querySelectorAll('.chipbtn').forEach(x=>{
    x.classList.remove('is-active');
    x.setAttribute('aria-selected','false');
  });
  btn.classList.add('is-active');
  btn.setAttribute('aria-selected','true');
  setIndustry(btn.dataset.industry);
});

function setIndustry(name){
  const data = industries[name];
  if(!data) return;
  document.getElementById('industryName').textContent = name;
  document.getElementById('industryDesc').textContent = data.desc;
  document.getElementById('industryBullets').innerHTML = data.bullets.map(x=>`<span>${x}</span>`).join('');
}

// Accordion
document.addEventListener('click', (e)=>{
  const b = e.target.closest('.acc');
  if(!b) return;
  const all = document.querySelectorAll('.acc');
  all.forEach(x=>x.classList.remove('is-open'));
  b.classList.add('is-open');
});

// Work filter
document.addEventListener('click', (e)=>{
  const f = e.target.closest('.fbtn');
  if(!f) return;
  document.querySelectorAll('.fbtn').forEach(x=>x.classList.remove('is-active'));
  f.classList.add('is-active');
  const key = f.dataset.filter;
  document.querySelectorAll('#workGrid .workcard').forEach(card=>{
    if(key === 'all'){ card.style.display='block'; return; }
    const tags = (card.dataset.tags || '').split(',').map(s=>s.trim());
    card.style.display = tags.includes(key) ? 'block' : 'none';
  });
});

// Timeline slider
const timeline = {
  1:{label:'Step 1: Discover — Workflow mapping', items:['Process mapping (current & desired)','Define roles, approvals and key reports','Clarify scope + phased roadmap']},
  2:{label:'Step 2: Design — System blueprint', items:['Wireframes & modules','Data model & permissions','Milestones + sign-offs']},
  3:{label:'Step 3: Build — Agile sprints', items:['Weekly deliverables','QA + review cycles','Secure access & audit trails']},
  4:{label:'Step 4: Deploy — Training & rollout', items:['Go-live checklist','Team training','Support & iteration']}
};
const range = document.getElementById('timelineRange');
if(range){
  range.addEventListener('input', ()=>{
    const step = Number(range.value);
    const d = timeline[step];
    document.getElementById('timelineLabel').innerHTML = `${d.label}<div class="muted small">No surprises • Weekly check-ins • Clear sign-offs</div>`;
    document.getElementById('timelineBody').innerHTML = `<ul>${d.items.map(i=>`<li>${i}</li>`).join('')}</ul>`;
  });
}

// Reveal on scroll + count-up
const io = new IntersectionObserver((entries)=>{
  for(const ent of entries){
    if(ent.isIntersecting){
      ent.target.classList.add('is-in');
      io.unobserve(ent.target);
      if(ent.target.querySelector && ent.target.querySelector('[data-count]')){
        runCounters(ent.target);
      }
    }
  }
},{threshold:0.12});

document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

function runCounters(scope){
  const els = (scope || document).querySelectorAll('[data-count]');
  els.forEach(el=>{
    const target = Number(el.getAttribute('data-count')||0);
    const duration = 850;
    const start = performance.now();
    const isBig = target >= 1000;
    function tick(now){
      const p = Math.min(1,(now-start)/duration);
      const val = Math.round(target*p);
      el.textContent = isBig ? (val.toLocaleString() + '+') : String(val) + (target>=10 ? '+' : '');
      if(p < 1) requestAnimationFrame(tick);
      else el.textContent = (target>=1000 ? target.toLocaleString()+'+' : target+'+');
    }
    // If the element already has text like "Dubai" ignore
    if(Number.isFinite(target) && target>0) requestAnimationFrame(tick);
  });
}

// Gallery modal (placeholders)
const galleryData = {
  "BlueForceOps": [
    { title: "Dashboard", src: "img/blueforce/dashboard.png" },
    { title: "Documents", src: "img/blueforce/document.png" },
    { title: "Attendance", src: "img/blueforce/attendance.png" },
    { title: "Camp Mgmt", src: "img/blueforce/camp.png" }
  ],

  "ValetPark": [
    { title: "Tickets", src: "img/valetpark/tickets.png" },
    { title: "Admin", src: "img/valetpark/admin.png" },
    { title: "Reports", src: "img/valetpark/reports.png" },
    { title: "Operations", src: "img/valetpark/operations.png" }
  ],

  "Office CRM": [
    { title: "Leads", src: "img/officecrm/leads.png" },
    { title: "Follow-ups", src: "img/officecrm/followups.png" },
    { title: "Quotations", src: "img/officecrm/quotations.png" },
    { title: "Accounts", src: "img/officecrm/accounts.png" }
  ],

  "Marine Tools": [
    { title: "Noon Report", src: "img/marine/noon-report.png" },
    { title: "Pre-arrival", src: "img/marine/pre-arrival.png" },
    { title: "ROB", src: "img/marine/rob.png" },
    { title: "Performance", src: "img/marine/performance.png" }
  ],

  "Shortlist Pro": [
    { title: "Pipeline", src: "img/shortlist/pipeline.png" },
    { title: "Scoring", src: "img/shortlist/scoring.png" },
    { title: "Shortlist", src: "img/shortlist/shortlist.png" },
    { title: "Decision", src: "img/shortlist/decision.png" }
  ],

  "Document Management": [
    { title: "Vault", src: "img/documents/vault.png" },
    { title: "Expiry Alerts", src: "img/documents/expiry.png" },
    { title: "Approvals", src: "img/documents/approvals.png" },
    { title: "Access", src: "img/documents/access.png" }
  ],

  "Competency Analysis": [
    { title: "Skill Matrix", src: "img/competency/skill-matrix.png" },
    { title: "Evaluation", src: "img/competency/evaluation.png" },
    { title: "Analytics", src: "img/competency/analytics.png" },
    { title: "Reports", src: "img/competency/reports.png" }
  ],

  "Project Management": [
    { title: "Tasks", src: "img/project/tasks.png" },
    { title: "Milestones", src: "img/project/milestones.png" },
    { title: "Approvals", src: "img/project/approvals.png" },
    { title: "Progress", src: "img/project/progress.png" }
  ]
};


function openGallery(name){
  return true
  const modal = document.getElementById('galleryModal');
  modal.classList.add('is-open');
  modal.setAttribute('aria-hidden','false');
  document.getElementById('galleryTitle').textContent = name + ' • Gallery';

  const thumbs = document.getElementById('thumbs');
  thumbs.innerHTML = '';
  const items = galleryData[name] || ["Screen 1","Screen 2","Screen 3","Screen 4"];
items.forEach((item, i) => {
  const div = document.createElement('div');
  div.className = 'thumb' + (i === 0 ? ' is-active' : '');
  div.textContent = item.title;
  div.onclick = () => setShot(item, div);
  thumbs.appendChild(div);
});

  setShot(items[0], thumbs.firstChild);
}
// function setShot(label, el){
//   document.querySelectorAll('.thumb').forEach(x=>x.classList.remove('is-active'));
//   if(el) el.classList.add('is-active');
//   document.getElementById('shotMain').textContent = label + ' (placeholder)';
// }

function setShot(item, el){
  document.querySelectorAll('.thumb').forEach(x => x.classList.remove('is-active'));
  if(el) el.classList.add('is-active');

  const img = document.getElementById('shotImage');
  img.src = item.src;
  img.alt = item.title;
}

function closeGallery(){
  const modal = document.getElementById('galleryModal');
  modal.classList.remove('is-open');
  modal.setAttribute('aria-hidden','true');
}

function fakeSubmit(e){
  e.preventDefault();
  alert('Form is UI-only in this prototype. Connect to WhatsApp/API in production.');
  return false;
}

// Close modals with ESC
document.addEventListener('keydown', (e)=>{
  if(e.key === 'Escape'){
    closeModal();
    closeGallery();
  }
});


// Subtle tilt (desktop only)
function initTilt(){
  if(window.matchMedia('(hover:hover) and (min-width: 980px)').matches){
    document.querySelectorAll('.tilt').forEach(card=>{
      card.addEventListener('mousemove', (e)=>{
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left)/r.width - 0.5;
        const y = (e.clientY - r.top)/r.height - 0.5;
        const rx = (-y*3).toFixed(2);
        const ry = (x*5).toFixed(2);
        card.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-2px)`;
      });
      card.addEventListener('mouseleave', ()=>{ card.style.transform = ''; });
    });
  }
}
window.addEventListener('load', initTilt);
