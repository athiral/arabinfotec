<?php
/**
 * send-inquiry.php
 * Secure, production-ready AJAX form handler
 */

/* =========================================================
   HEADERS & HARD BLOCKS
========================================================= */
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

ini_set('display_errors', 0);
error_reporting(0);

/* =========================================================
   HELPERS
========================================================= */
function respond(bool $success, string $message, int $code = 200, array $extra = []): void {
    http_response_code($code);
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message
    ], $extra));
    exit;
}

function clean($v): string {
    return trim((string)$v);
}

function h($v): string {
    return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/* =========================================================
   METHOD & ORIGIN VALIDATION
========================================================= */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'Invalid request.', 405);
}

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowedOrigins = [
    'https://arabinfotec.com',
    'https://www.arabinfotec.com'
];

if ($origin && !in_array($origin, $allowedOrigins, true)) {
    respond(false, 'Forbidden origin.', 403);
}

/* =========================================================
   CONFIG (MOVE TO ENV IN REAL DEPLOYMENT)
========================================================= */
define('RECAPTCHA_SECRET', '6Ld0nUAsAAAAACSKi9MO6nAy2NovHzlg8l04TSyP');

// define('SMTP_HOST', 'ded6951.inmotionhosting.com');
define('SMTP_HOST', 'server.virtualsystec.com');
define('SMTP_USER', 'mailer@arabinfotec.com');
define('SMTP_PASS', '2uumwpFKXA8Y');
define('SMTP_PORT', 587);

define('ADMIN_EMAIL', 'hello@arabinfotec.com');
define('ADMIN_WHATSAPP', '971543697999');

define('CC_EMAILS', [
     'info@arabinfotechllc.com',
    'sreechand@arabinfotechllc.com',
    'sreechand@vstbiz.com',
    'sangeeta@vstbiz.com',
    'praveen@vstbiz.com'
]);

define('WEBHOOK_URL', 'https://affiliate.arabinfotechllc.com/index.php/webhooks/crm');
define('WEBHOOK_SECRET', '9zPouKYgGFQyeMvEJsiqtTie');
/* =========================================================
   HONEYPOT (SILENT BOT TRAP)
========================================================= */
if (!empty($_POST['hp_name'])) {
    respond(true, 'Thanks!');
}

/* =========================================================
   HUMAN TIMING CHECK (ANTI-BOT)
========================================================= */
$formTime = (int)($_POST['form_loaded_at'] ?? 0);
if ($formTime && (time() * 1000 - $formTime) < 3000) {
    respond(false, 'Submission too fast.', 429);
}

/* =========================================================
   READ & SANITIZE INPUT
========================================================= */
$business = clean($_POST['business_name'] ?? '');
$name     = clean($_POST['contact_person'] ?? '');
$phone    = clean($_POST['phone'] ?? '');
$email    = clean($_POST['email'] ?? '');
$website  = clean($_POST['current_website'] ?? '');
$industry = clean($_POST['industry'] ?? '');
$goal     = clean($_POST['main_goal'] ?? '');
$timeline = clean($_POST['timeline'] ?? '');
$notes    = clean($_POST['notes'] ?? '');
$ad_source    = clean($_POST['ad_source'] ?? '');
$sourcetag    = clean($_POST['sourcetag'] ?? '');
$utm_campaign = clean($_POST['utm_campaign'] ?? '');
$recaptcha_token = $_POST['recaptcha_token'] ?? '';

/* =========================================================
   INPUT VALIDATION
========================================================= */
if (!$business || !$name || !$phone || !$email || !$industry || !$goal || !$timeline) {
    respond(false, 'Please fill all required fields.', 400);
}
if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(false, 'Invalid email address.', 400);
}
if (strlen($notes) > 2000) {
    respond(false, 'Message too long.', 400);
}
if (!$recaptcha_token) {
    respond(false, 'Captcha token missing.', 400);
}
/* =========================================================
   reCAPTCHA v3 VALIDATION
========================================================= */
$verify = @file_get_contents(
    'https://www.google.com/recaptcha/api/siteverify?secret=' .
    urlencode(RECAPTCHA_SECRET) .
    '&response=' . urlencode($recaptcha_token)
);
if (!$verify) {
    respond(false, 'Captcha service unavailable.', 400);
}
$captcha = json_decode($verify, true);
if (
    empty($captcha['success']) ||
    ($captcha['score'] ?? 0) < 0.3 ||
    ($captcha['action'] ?? '') !== 'lead_form'
) {
    respond(false, 'Captcha verification failed.', 400);
}

/* =========================================================
   RATE LIMITING (IP + PHONE)
========================================================= */
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

$ipFile = sys_get_temp_dir() . '/lead_ip_' . md5($ip);
$phoneFile = sys_get_temp_dir() . '/lead_phone_' . md5($phone);

if ((file_exists($ipFile) && time() - filemtime($ipFile) < 10) ||
    (file_exists($phoneFile) && time() - filemtime($phoneFile) < 60)) {
    respond(false, 'Duplicate submission detected.', 429);
}

touch($ipFile);
touch($phoneFile);

/* =========================================================
   SEND TO CRM WEBHOOK
========================================================= */
$remarks = "";

if (!empty($website)) {
    $remarks .= "Current Website (URL): {$website}\n";
}
if (!empty($industry)) {
    $remarks .= "Industry: {$industry}\n";
}
if (!empty($goal)) {
    $remarks .= "Main Goal: {$goal}\n";
}
if (!empty($timeline)) {
    $remarks .= "Target Timeline: {$timeline}\n";
}
if (!empty($notes)) {
    $remarks .= "Notes: {$notes}";
}

$payload = [
    'name'       => $name,
    'contact_type' => 4,
    'email'      => $email,
    'mobile'     => $phone,
    'company'    => $business,
    'company_website' => $website,
    'remarks'    => $remarks,
    'status'     => 1,
    'completed_percentage' => 0,
    'contact_source' => 25,
    'contact_priority' => 2,
    'contact_states' => 1,
    'created_at' => date('Y-m-d H:i:s'),
    'ad_source'  => $ad_source,
    'sourcetag'  => $sourcetag,
    'utm_campaign' => $utm_campaign
];

$payloadJson = json_encode($payload);
$signature = hash_hmac('sha256', $payloadJson, WEBHOOK_SECRET);

$ch = curl_init(WEBHOOK_URL);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => $payloadJson,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'X-Webhook-Signature: ' . $signature,
    'Content-Length: ' . strlen($payloadJson),
    'Origin: https://arabinfotec.com'
    ],
     CURLOPT_REFERER => 'https://arabinfotec.com/website-design/',
    CURLOPT_TIMEOUT => 5,
    CURLOPT_SSL_VERIFYPEER => true
]);
curl_exec($ch);
curl_close($ch);


/*
==================================================
SEND DATA TO CRM VIA WEBHOOK - disabled
==================================================
*/
/*
$webhook_url = 'https://affiliate.arabinfotechllc.com/index.php/webhooks/crm';

$webhook_secret = '9zPouKYgGFQyeMvEJsiqtTie';

$remarks = "";

if (!empty($website)) {
    $remarks .= "Current Website (URL): {$website}\n";
}
if (!empty($industry)) {
    $remarks .= "Industry: {$industry}\n";
}
if (!empty($goal)) {
    $remarks .= "Main Goal: {$goal}\n";
}
if (!empty($timeline)) {
    $remarks .= "Target Timeline: {$timeline}\n";
}
if (!empty($notes)) {
    $remarks .= "Notes: {$notes}";
}

$webhook_data = [
    'name' => $name,
    'contact_type' => 4,
    'email' => $email,
    'mobile' => $phone,
    'company' => $business,
    'company_website' => $website,
    'remarks' => $remarks,
    'status' => 1,
    'completed_percentage' => 0,
    'contact_source' => 25,
    'contact_priority' => 2,
    'contact_states' => 1,
    'created_at' => date('Y-m-d H:i:s'),
    'ad_source' => $ad_source,
    'sourcetag' => $sourcetag,
    'utm_campaign' => $utm_campaign
];

$webhook_json = json_encode($webhook_data);
if ($webhook_json === false) {
    error_log('Webhook JSON encode failed');
    return;
}

$signature = hash_hmac('sha256', $webhook_json, $webhook_secret);

$ch = curl_init($webhook_url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => $webhook_json,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'X-Webhook-Signature: ' . $signature,
        'Content-Length: ' . strlen($webhook_json),
        'Origin: https://arabinfotec.com'
    ],
    CURLOPT_REFERER => 'https://arabinfotec.com/website-design/',
    CURLOPT_TIMEOUT => 5,
    CURLOPT_CONNECTTIMEOUT => 3,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    error_log('Webhook cURL Error: ' . curl_error($ch));
} elseif ($http_code !== 200) {
    error_log('Webhook failed. HTTP Code: ' . $http_code);
}

curl_close($ch);
*/
/* =========================================================
   END CRM WEBHOOK
========================================================= */




/* =========================================================
   SEND EMAIL (PHPMailer SMTP)
========================================================= */
require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;

try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->CharSet  = 'UTF-8';
    $mail->Encoding = 'base64';
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USER;
    $mail->Password   = SMTP_PASS;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = SMTP_PORT;

    $mail->setFrom(SMTP_USER, 'Arabinfotec – Website Review');
    $mail->addAddress(ADMIN_EMAIL);

    if ($email) {
        $mail->addReplyTo($email, $name);
    }

    // Add CC recipients
if (defined('CC_EMAILS') && is_array(CC_EMAILS)) {
    foreach (CC_EMAILS as $cc) {
        if (filter_var($cc, FILTER_VALIDATE_EMAIL)) {
            $mail->addCC($cc);
        }
    }
}


    $mail->isHTML(true);
    $mail->Subject = "New Website Review Request - {$business}";


    $uaeTime   = new DateTime('now', new DateTimeZone('Asia/Dubai'));
$indiaTime = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
$utcTime   = new DateTime('now', new DateTimeZone('UTC'));

$uaeTimeFormatted   = $uaeTime->format('d M Y, h:i A') . ' (UAE)';
$indiaTimeFormatted = $indiaTime->format('d M Y, h:i A') . ' (India)';
$utcTimeFormatted   = $utcTime->format('d M Y, h:i A') . ' (UTC)';



    $mail->Body = '
<div style="font-family:Arial,Helvetica,sans-serif;background:#f6f8fb;padding:24px;color:#0f172a">
  <div style="max-width:620px;margin:0 auto;background:#ffffff;border-radius:8px;
              box-shadow:0 4px 12px rgba(0,0,0,0.06);overflow:hidden">

    <!-- Header -->
    <div style="padding:20px 24px;border-bottom:1px solid #e5e7eb">
      <h2 style="margin:0;font-size:20px;font-weight:700;color:#0f172a">
        New Website Review Request
      </h2>
      <p style="margin:6px 0 0;font-size:13px;color:#64748b">
        A new enquiry has been submitted via the website
      </p>
    </div>

    <!-- Lead Details -->
    <div style="padding:20px 24px">
      <table width="100%" cellpadding="6" cellspacing="0"
             style="border-collapse:collapse;font-size:14px">
        <tr>
          <td style="width:32%;color:#475569;font-weight:600">Business</td>
          <td style="color:#0f172a">'.h($business).'</td>
        </tr>
        <tr>
          <td style="color:#475569;font-weight:600">Contact Person</td>
          <td>'.h($name).'</td>
        </tr>
        <tr>
          <td style="color:#475569;font-weight:600">Phone / WhatsApp</td>
          <td>'.h($phone).'</td>
        </tr>
        <tr>
          <td style="color:#475569;font-weight:600">Email</td>
          <td>'.h($email ?: "—").'</td>
        </tr>
        <tr>
          <td style="color:#475569;font-weight:600">Website</td>
          <td>'.h($website).'</td>
        </tr>
        <tr>
          <td style="color:#475569;font-weight:600">Industry</td>
          <td>'.h($industry).'</td>
        </tr>
        <tr>
          <td style="color:#475569;font-weight:600">Main Goal</td>
          <td>'.h($goal ?: "—").'</td>
        </tr>
        <tr>
          <td style="color:#475569;font-weight:600">Target Timeline</td>
          <td>'.h($timeline ?: "—").'</td>
        </tr>

        <tr>
          <td style="color:#475569;font-weight:600">Source Type</td>
          <td>'.h($ad_source ?: "—").'</td>
        </tr>

      </table>

      <!-- Notes -->
      <div style="margin-top:18px">
        <div style="font-size:14px;font-weight:600;color:#475569;margin-bottom:6px">
          Notes
        </div>
        <div style="background:#f8fafc;border:1px solid #e5e7eb;
                    border-left:4px solid #2563eb;
                    padding:12px;border-radius:4px;
                    font-size:14px;color:#0f172a;line-height:1.6">
          '.nl2br(h($notes ?: "—")).'
        </div>
      </div>

      <!-- Mail Sent Details -->
      <div style="margin-top:16px;padding-top:12px;
                  border-top:1px dashed #e5e7eb;
                  font-size:12px;color:#64748b;line-height:1.6">

        <div style="font-weight:600;margin-bottom:4px;color:#475569">
          Mail Sent Details
        </div>

        <div>
          UAE Time:
          <strong style="color:#334155">'.$uaeTimeFormatted.'</strong><br>
          India Time:
          <strong style="color:#334155">'.$indiaTimeFormatted.'</strong><br>
          UTC Time:
          <strong style="color:#334155">'.$utcTimeFormatted.'</strong>
        </div>

      </div>
    </div>

    <!-- Footer -->
    <div style="padding:14px 24px;background:#f8fafc;
                border-top:1px solid #e5e7eb;
                font-size:12px;color:#64748b">
      This message was generated automatically from
      <strong>arabinfotec.com/website-design</strong><br>
      Website Design & Review Enquiries
    </div>

  </div>
</div>';

  $mail->send();
} catch (Exception $e) {
    error_log('Mail error: ' . $e->getMessage());
    respond(false, 'Unable to send email.', 500);
}

/* =========================================================
   WHATSAPP ADMIN LINK
========================================================= */
$wa_msg = urlencode(
    "New Website Review Lead\n\n".
    "Business: {$business}\n".
    "Contact: {$name}\n".
    "Phone: {$phone}\n".
    "Website: {$website}"
);

$whatsapp_link = "https://wa.me/" . ADMIN_WHATSAPP . "?text=" . $wa_msg;

/* =========================================================
   FINAL RESPONSE
========================================================= */
// respond(true, 'Thanks — we will contact you shortly.', 200, [
//     'whatsapp_notify' => $whatsapp_link
// ]);
 respond(true, 'Thanks — we will contact you shortly.', 200);
